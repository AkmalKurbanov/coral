$(window).on("load", function () {
  setTimeout(function () {
    $(".backlight-js").addClass("active");
  }, 500); // Задержка в 1 секунду (1000 миллисекунд)
});
